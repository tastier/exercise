#include "query.h"

using namespace std;

int main(int argc, char **argv)
{
	ifstream infile;
	infile.open(argv[1]);
	text_query tq(infile);
	query q1("fiery"), q2("bird"), q3("wind");
	query q = q1 & q2 | q3;
	query_result result = q.eval(tq);
	cout << q.rep() << endl;
	cout << result << endl;

	return 0;
}
