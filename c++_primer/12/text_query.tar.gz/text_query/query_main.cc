#include <text_query.h>

using namespace std;
int main(int argc, char **argv)
{
	ifstream infile;
	infile.open(argv[1]);
	text_query tq(infile);
	string word;
	while(ture) {
		cout << "input word: ";
		cin >> word;
		cout << tq.query(word)<<endl;
	}
}
