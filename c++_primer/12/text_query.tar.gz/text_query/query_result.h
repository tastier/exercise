#ifndef QUERY_RESULT_H
#define QUERY_RESULT_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <memory>
#include <map> 
#include <set>

class query_result {
friend std::ostream& operater<<(std::ostream &, query_result &);
public:
	typedef std::vector<std::string>::size_type line_no;
	query_result(std::string str, 
				 std::shared_ptr<std::vector<std::string>> f,
				 std::shared_ptr<std::set<line_no>> p) :
		sought(str), file(f), lines(p) {};
private:
	std::string sought;
	std::shared_ptr<std::vector<std::string>> file;
	std::shared_ptr<std::set<line_no>> lines;
};

std::ostream& operater<<(std::ostream &os, query_result &qr)
{
	if(!qr.lines)
		os << qr.sought << " occurs " << "0 time."<<endl;
	else {
		os << qr.sought << " occurs " << qr.lines->size() 
			<< " times " << endl;
		for (auto line = qr.lines->begin(); 
				line != qr.line->end(); ++line ) {
			os << "(line: " << *line + 1 << ")" 
				<< *(qr.file->begin() + *line) << endl;
		}
	}

	return os;
}

#endif
